package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EzhaarController implements Initializable {

    @FXML
    private RadioButton air;

    @FXML
    private RadioButton sea;

    @FXML
    private RadioButton land;
    
    @FXML
    private DatePicker date;
        
    @FXML
    private TextField sid;
    
    @FXML
    private TextField sname;
    
    @FXML
    private TextField fname;
    
    @FXML
    private TextField totalVal;
    
    @FXML
    private TextField country;
    
    @FXML
    private TextField itemName;
    
    @FXML
    private TextField itemWeight;
    
    @FXML
    private TextField unitCost;
    
    @FXML
    private TextField company;
    
    @FXML
    private TextField quantity;
    
    @FXML
    private void submitForm(ActionEvent event) throws IOException {
        UserRepo repo=UserRepo.getRepo();
        Salesman saleman;
        Item item;
        Ezhaarname ez;
        
        if (date.getValue()==null || quantity.getText().equals("") || company.getText().equals("") || unitCost.getText().equals("") || itemWeight.getText().equals("") || itemName.getText().equals("") || country.getText().equals("") || totalVal.getText().equals("") || sname.getText().equals("") || fname.getText().equals("") || sid.getText().equals(""))
        {
            Parent root = FXMLLoader.load(getClass().getResource("emptyFieldError.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
            
        }
        else
        {
            try{
            saleman=repo.findSaleman(Integer.parseInt(sid.getText()),sname.getText(),fname.getText());
            item=new Item(itemName.getText(),company.getText(),Integer.parseInt(itemWeight.getText()),Integer.parseInt(unitCost.getText()));
            ez=new Ezhaarname(date.getValue().toString(),Integer.parseInt(totalVal.getText()),country.getText(),Integer.parseInt(quantity.getText()),saleman,item);
            if(air.isSelected())
                ez.setType("air");
            else if(sea.isSelected())
                ez.setType("sea");
            
            repo.addezhaarname(ez);//transType //// mojavez daar shod vaziat yek she
            saleman.ezList.add(ez);
            
            Parent root = FXMLLoader.load(getClass().getResource("requiredMojavezs.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();}
            catch(Exception e){
                Parent root = FXMLLoader.load(getClass().getResource("wrongFormatError.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);
        
                stage.setScene(scene);
                stage.show();
            
                ((Node)(event.getSource())).getScene().getWindow().hide();
            }
        }
    }
        
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
