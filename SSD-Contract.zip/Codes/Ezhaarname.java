package softwareeng;

public class Ezhaarname {
    private String date;
    private int totalVal;
    private String country;
    private String transType;
    private int quantity;
    private Salesman salesman;
    private Item item;
    private boolean status;
    
    public Ezhaarname(String d,int tval,String cnt,int quan,Salesman sman,Item i){
        date=d;
        salesman=sman;
        totalVal=tval;
        country=cnt;
        transType="land";
        quantity=quan;
        item=i;
        status=false;
    }
    
    public void setType(String t){
        transType=t;
    }
    
    
}
