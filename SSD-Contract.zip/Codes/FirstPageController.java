package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.util.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FirstPageController implements Initializable {
    
    @FXML
    private TextField username;
    
    @FXML
    private PasswordField passwrd;
    
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        UserRepo repo=UserRepo.getRepo();
        
        String s=username.getText();
        String p=passwrd.getText();
      
        if (repo.isValidUser(s,p)){
            Parent root = FXMLLoader.load(getClass().getResource("Ezhaar.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
        } 
         else
        {
            Parent root = FXMLLoader.load(getClass().getResource("ErrorLogin.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
        
        
              
    }
    
        @FXML
    private void handleButtonAction1(ActionEvent event) throws IOException {
        UserRepo repo=UserRepo.getRepo();
        
        String s=username.getText();
        String p=passwrd.getText();
      
        if (repo.addUser(s,p)){
            Parent root = FXMLLoader.load(getClass().getResource("Ezhaar.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
        } 
        else
        {
            Parent root = FXMLLoader.load(getClass().getResource("Error.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
