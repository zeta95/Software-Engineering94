package softwareeng;

import java.util.*;

public class Salesman {
    private int id;
    private String name;
    private String family;
    
    public ArrayList<Ezhaarname> ezList;
    
    public Salesman(int i,String n,String f){
        ezList=new ArrayList<Ezhaarname>();
        id=i;
        name=n;
        family=f;
    }
    
    public int getID(){
        return id;
    }
    
}
