package softwareeng;

import java.util.*;
import java.lang.*;

public class UserRepo {
    
    private static ArrayList<User> users;
    private static ArrayList<Salesman> salemans;
    private static ArrayList<Ezhaarname> ezhaarnameList;
    
    private static UserRepo repo;
    
    private UserRepo(){
        users = new ArrayList<User>();
        salemans= new ArrayList<Salesman>();
        ezhaarnameList= new ArrayList<Ezhaarname>();
        users.add(new User("admin","1234"));
    }
    
    public static UserRepo getRepo(){
        if (repo==null){
            repo=new UserRepo();
        }
        return repo;
    }
    
    public boolean isValidUser(String un,String pw){
        return users.stream().anyMatch((u) -> (u.getUsername().equals(un) && u.getPassword().equals(pw)));
    }
    
    public Salesman findSaleman(int id,String name,String fname){
        for (Salesman sm:salemans){
            if(sm.getID()==id){
                return sm;
            }
        }
        return new Salesman(id,name,fname);
        
    }
    
    public boolean addUser(String un,String pw){
        if (users.stream().anyMatch((u) -> (u.getUsername().equals(un))))
            return false;
        users.add(new User(un,pw));
        return true;
    }
    
    public void addezhaarname(Ezhaarname ez){
        ezhaarnameList.add(ez);  
    }
    
}
