drop table users if exists
drop table mojusers if exists
drop table ezhaarnames if exists
drop table companies if exists
drop table salesman if exists
drop table certificates if exists
drop table UsrCrt if exists
drop table companieslist if exists
drop table rules if exists

create table users (
    username varchar(100) not null,
    password varchar(100) not null,
    type varchar(10) not null,
    primary key (username)
)

create table mojusers (
    username varchar(100) not null,
    company varchar(100) not null,
    primary key (username)
)

create table ezhaarnames(
    code integer not null,
    date varchar(10) not null,
    totalcost integer not null,
    country varchar(100) not null,
    transType varchar(4) not null,
    quantity integer not null,
    sid integer not null,
    iname varchar(100) not null,
    icompany varchar(100) not null,
    iweight integer not null,
    iunitPrice integer not null,
    primary key(code)
)

create table companies (
    name varchar(100) not null,
    mojavez varchar(100) not null,
    primary key (name,mojavez)
)

create table salesman (
    name varchar(100) not null,
    family varchar(100) not null,
    id integer not null,
    primary key (id)
)

create table certificates (
    sid integer not null,
    certID integer not null,
    name varchar(100) not null,
    item varchar(100) not null,
    quantity integer not null,
    transType varchar(10) not null,
    country varchar(100) not null,
    weight integer not null,
    dueDate varchar(100) not null,
    company varchar(100) not null,    
    primary key (certID)
)

create table UsrCrt (
    sid integer not null,
    certID integer not null,
    primary key (certID)
)

create table companieslist (
    name varchar(100) not null,
    primary key(name)
)

create table rules(
   iName varchar(100) not null,
   mName varchar(100) not null,
   minQuantity integer,
   maxQuantity integer,
   country varchar(100),
   minPrice integer,
   maxPrice integer,
   fromDate varchar(100),
   toDate varchar(100),
   transType varchar(100),
   company varchar(100),
   minWeight integer,
   maxWeight integer
)
