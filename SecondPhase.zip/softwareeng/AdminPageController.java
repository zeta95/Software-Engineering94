package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author negar
 */
public class AdminPageController implements Initializable {
    
    @FXML
    private RadioButton ez;

    @FXML
    private RadioButton moj;
            
    @FXML
    private TextField username;
    
    @FXML
    private TextField passwrd;
    
    @FXML
    private RadioButton air;

    @FXML
    private RadioButton sea;

    @FXML
    private RadioButton land;
    
    @FXML
    private DatePicker fdate;
    
    @FXML
    private DatePicker tdate;
        
    @FXML
    private TextField iname;
    
    @FXML
    private TextField mname;
        
    @FXML
    private TextField minprice;
    
    @FXML
    private TextField country;
    
    @FXML
    private TextField maxprice;
    
    @FXML
    private ChoiceBox company;
    
    @FXML
    private ChoiceBox mojCompany;
    
    @FXML
    private TextField minQuantity;
    
    @FXML
    private TextField maxQuantity;
        
    @FXML
    private TextField minWeight;
            
    @FXML
    private TextField maxWeight;
    
    @FXML
    private TextField newcompany;
    
    @FXML
    private TextField certName;
    
    @FXML
    private ChoiceBox userCompanyChoice;

    
 @FXML
    private void addUser(ActionEvent event) throws IOException {
        
        UserRepo repo=UserRepo.getRepo();    
        
        String s=username.getText();
        String p=passwrd.getText();
        String selectedCompany=(String)userCompanyChoice.getValue();

        String t="ez";
        if(ez.isSelected())
            t="ez";
        else if(moj.isSelected())
            t="moj";
      
        if (repo.addUser(s,p,t,selectedCompany)){
            Parent root = FXMLLoader.load(getClass().getResource("addSuccess.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
        } 
        else
        {
            Parent root = FXMLLoader.load(getClass().getResource("Error.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
        
    }
    
     @FXML
    private void addMojavez(ActionEvent event) throws IOException {
        
        UserRepo repo=UserRepo.getRepo();
        String selectedCompany=(String)mojCompany.getValue();
        Parent root;
        if(repo.getCompany(selectedCompany).addMojavez(certName.getText()))
            root = FXMLLoader.load(getClass().getResource("addMojavezSuccess.fxml"));
        else
            root = FXMLLoader.load(getClass().getResource("addMojavezRepeated.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
         
    }

    @FXML
    private void exitAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FirstPage.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    
    }
    
    @FXML
    private void addNewRule(ActionEvent event) throws IOException {
        String t="-1";
        UserRepo repo;
        if (air.isSelected())
            t="air";
        else if (sea.isSelected())
            t="sea";
        else if (land.isSelected())
            t="land";

         Parent root;
        if (UserRepo.getCompany((String)company.getValue()).contains(mname.getText())){
            UserRepo.addRule(iname.getText(),mname.getText(),minQuantity.getText().equals("")?-1:Integer.parseInt(minQuantity.getText()),maxQuantity.getText().equals("")?-1:Integer.parseInt(maxQuantity.getText()),country.getText().equals("")?"-1":country.getText(),minprice.getText().equals("")?-1:Integer.parseInt(minprice.getText()),maxprice.getText().equals("")?-1:Integer.parseInt(maxprice.getText()),fdate.getValue()==null?"-1":fdate.getValue().toString(),tdate.getValue()==null?"-1":tdate.getValue().toString(),t,(String)company.getValue(),minWeight.getText().equals("")?-1:Integer.parseInt(minWeight.getText()),maxWeight.getText().equals("")?-1:Integer.parseInt(maxWeight.getText()));
            root = FXMLLoader.load(getClass().getResource("addRuleSuccess.fxml"));
        }
        else
        {
            root = FXMLLoader.load(getClass().getResource("addRuleFail.fxml"));
        }

        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    
    }
    
    @FXML
    private void addNewCompany(ActionEvent event) throws IOException {
        UserRepo repo;
        Parent root;
        if(UserRepo.addCompany(newcompany.getText()))
            root = FXMLLoader.load(getClass().getResource("addCompanySuccess.fxml"));
        else
            root = FXMLLoader.load(getClass().getResource("addCompanyRepeated.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        UserRepo repo=UserRepo.getRepo();
        userCompanyChoice.setItems(FXCollections.observableArrayList(repo.getCompaniesNames()));
        mojCompany.setItems(FXCollections.observableArrayList(repo.getCompaniesNames()));
        company.setItems(FXCollections.observableArrayList(repo.getCompaniesNames()));
    }    
    
}
