package softwareeng;

public class Certificate {
    
    private String name;
    private int uniqueCode;
    
    private String item;//name kala
    private int quantity;//tedade kala
    private String country; /// keshvar
    private int weight;
    private String dueDate;
    private String transType;//nahve voroud
    private String company;
    public Certificate(String n , int uc, String i , int num  , String ctry ,int w, String dd , String tt,String comp){
        name = n;
        uniqueCode = uc;
        item = i;
        quantity = num;
        transType = tt;
        country= ctry;
        weight = w;
        dueDate =dd;
        company=comp;
    }
    
    public String getName(){
        return name;
    }
    
    public void setTranstype(String tt){
        transType = tt;
    }
    public String getTranstype (){
        return transType;
    }
    
    public void setUniqueCode(int uc){
        uniqueCode = uc;
    }
    public int getUniqueCode(){
        return uniqueCode;
    }
    
    public String getItem(){
        return item;
    }
    
    
    public String getTransType(){
        return transType;
    }
    
    
    public String getCountry(){
        return country;
    }
}

