package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
/**
 * FXML Controller class
 *
 * @author zeta
 */
public class EnterRequiredMojavezController implements Initializable {
    
    @FXML
    private Label certName;
    
    @FXML
    private TextField certNum;
    
    @FXML
    private Text error;
    
    private ArrayList<String> reqCerts;
    private int index;
    private Ezhaarname ezhaar;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   
    
    @FXML
    private void checkCert(ActionEvent event) throws IOException {

        if (Rules.isAppropriateCert(ezhaar,certNum.getText(),reqCerts.get(index))){

            if(index==reqCerts.size()-1){
                UserRepo repo = UserRepo.getRepo();
                int code = repo.finalizeEzhaar(ezhaar);
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("ezhaarSuccess.fxml"));
                Stage stage = new Stage(StageStyle.DECORATED);
                stage.setScene(new Scene((Pane) loader.load()));

                EzhaarSuccessController controller = loader.<EzhaarSuccessController>getController();
                controller.initData(code);

                stage.show();

                ((Node)(event.getSource())).getScene().getWindow().hide();
            }

            else{
                FXMLLoader loader = new FXMLLoader(getClass().getResource("enterRequiredMojavez.fxml"));
                Stage stage = new Stage(StageStyle.DECORATED);
                stage.setScene(new Scene((Pane) loader.load()));

                EnterRequiredMojavezController controller = loader.<EnterRequiredMojavezController>getController();
                controller.initData(reqCerts,index+1,ezhaar);

                stage.show();

                ((Node)(event.getSource())).getScene().getWindow().hide();
            }
        
        }
        
        else{
            error.setVisible(true);
        }
    }
    
    @FXML
    private void logout(ActionEvent event) throws IOException {
        ezhaar.emptyCerts();
        
        Parent root = FXMLLoader.load(getClass().getResource("FirstPage.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    }
   
    
    public void initData(ArrayList<String> rc, int i, Ezhaarname ez){
        ezhaar = ez;
        index = i;
        reqCerts = rc;
        
        certName.setText(reqCerts.get(i));
    }
}
