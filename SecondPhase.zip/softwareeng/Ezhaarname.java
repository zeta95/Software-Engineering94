package softwareeng;

import java.util.ArrayList;

public class Ezhaarname {
    private String date;
    private int totalVal;
    private String country;
    private String transType;
    private int quantity;
    private Salesman salesman;
    private Item item;
    
    private ArrayList<String> usedCerts = new ArrayList<String> (); // certs to be updated
    
    private int id;//////////// dar hengaami ke be db ezafe mishavad(dar repo) bayad unique id ham set shvad
    
    public Ezhaarname(String d,int tval,String cnt,int quan,Salesman sman,Item i){
        date=d;
        salesman=sman;
        totalVal=tval;
        country=cnt;
        transType="land";
        quantity=quan;
        item=i;
    }
    
    public void setType(String t){
        transType=t;
    }
    
    public String getDate(){
        return date;
    }
    
    public int getTotal(){
        return totalVal;
    }
    
    public String getCountry(){
        return country;
    }
    
    public String getTransType(){
        return transType;
    }
    
    public int getQuantity(){
        return quantity;
    }
    
    public Salesman getSalesman(){
        return salesman;
    }
    
    public Item getItem(){
        return item;
    }
    
    public void setID(int i){ //////// tavasote repo call mishavad (dar zamani ke dar db add mishavad
        id = i;
    }
    
    public void addCert(String certNum){
        usedCerts.add(certNum);
    }
    
    public void emptyCerts(){
        usedCerts.clear();
    }
    
    public ArrayList<String> getCertificates(){
        return usedCerts;
    }
}
