package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.util.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class FirstPageController implements Initializable {
    
    @FXML
    private TextField username;
    
    @FXML
    private PasswordField passwrd;
    
    @FXML
    private void loginAction(ActionEvent event) throws IOException {
        UserRepo repo=UserRepo.getRepo();
        
        
        String s=username.getText();
        String p=passwrd.getText();
       
    
        
        
        
        
        
        
        
        
        
        
        if (repo.isAdmin(s,p)){
            
            Parent root = FXMLLoader.load(getClass().getResource("adminPage.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
            
        else if (repo.isValidUser(s,p)){
            if(repo.isEzUser(s,p)){
                Parent root = FXMLLoader.load(getClass().getResource("Ezhaar.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);

                stage.setScene(scene);
                stage.show();

                ((Node)(event.getSource())).getScene().getWindow().hide();
            }
     
            else if (repo.isMojUser(s,p)){
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Niloomojavez.fxml"));

                Stage stage = new Stage(StageStyle.DECORATED);
                stage.setScene(new Scene((Pane) loader.load()));

                NiloomojavezController controller = loader.<NiloomojavezController>getController();
                controller.initData(repo.getUserCompany(s));

                stage.show();

                ((Node)(event.getSource())).getScene().getWindow().hide();
            }
               
        } 
         else
        {
            Parent root = FXMLLoader.load(getClass().getResource("ErrorLogin.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
        
        
              
    }
        
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
