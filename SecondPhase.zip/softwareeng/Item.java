package softwareeng;

public class Item {
    private String name;
    private String company;
    private int weight;
    private int unitPrice;
    
    public Item(String n,String c,int w,int up){
        name=n;
        company=c;
        weight=w;
        unitPrice=up;
    }
    
    public String getName(){
        return name;
    }
    
    public String getCompany(){
        return company;
    }
    
    public int getWeight(){
        return weight;
    }
    
    public int getUnitPrice(){
        return unitPrice;
    }
}
