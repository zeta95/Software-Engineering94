package softwareeng;

public class MojUser extends User{
    
    private Company company;
        
    public MojUser (String u, String p,String t, Company c){
        super(u,p,t);
        company=c;
    }
    
    public Company getCompany(){
        return company;
    }
    
}
