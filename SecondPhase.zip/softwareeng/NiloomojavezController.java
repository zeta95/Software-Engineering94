package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import static softwareeng.UserRepo.CONN_STR;

/**
 * FXML Controller class
 *
 * @author Niloofar.Sh
 */
public class NiloomojavezController implements Initializable {
    
    private ArrayList<String> certs;

    @FXML
    private ChoiceBox mojavezhaa ;

    @FXML
    private Label l;
            
    @FXML 
    private Button b;
  
    @FXML
    private TextField ii;
    
    @FXML
    private TextField nn;
    
    @FXML
    private TextField cc;
    
    @FXML
    private TextField com;
    
    @FXML
    private TextField ww;
   
    @FXML
    private TextField nu;
    
    @FXML
    private TextField p;
    
    @FXML
    private RadioButton air;
    
    @FXML
    private RadioButton sea;
    
    @FXML
    private RadioButton earth;
    
    @FXML
    private DatePicker dd;
    
    @FXML
    private Button sodoor;
    
    private String companyName;
    
    @FXML
    private void submitForm(ActionEvent event) throws IOException {
        UserRepo repo=UserRepo.getRepo();
        Salesman saleman;
      
        Certificate mojavez;
        
        if ( mojavezhaa.getValue() == null || dd.getValue()==null || ii.getText().equals("") || nn.getText().equals("") || cc.getText().equals("") || ww.getText().equals("") || com.getText().equals("") || nu.getText().equals("") || p.getText().equals("") )
        {
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EmptyFieldMoj.fxml"));

            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene((Pane) loader.load()));

            EmptyFieldMojController controller = loader.<EmptyFieldMojController>getController();
            controller.initData(companyName);

            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
            
            
        }
        else
        {
            try{
                int id=repo.generateCertId();
                String transType="land";
                //saleman=repo.findSalemanByid(Integer.parseInt(ii.getText()));
     
           //mojavez =  new Certificate(mojavezhaa.getSelectionModel().getSelectedItem().toString()  , nn.getText() , Integer.parseInt(nu.getText())  , cc.getText() ,Integer.parseInt(ww.getText()),dd.getValue().toString() );
         
            if(air.isSelected())
                transType="air";
            else if(sea.isSelected())
                transType="sea";
            
                try{
                    Connection con = DriverManager.getConnection(CONN_STR);
                    Statement st = con.createStatement();
                    st.executeUpdate("insert into certificates values ('" + ii.getText() +"', '" + id + "', '" + (String)mojavezhaa.getValue() + "', '" +
                    nn.getText() + "', '" + Integer.parseInt(nu.getText()) + "', '" + transType + "', '" +
                    cc.getText() + "', '" + Integer.parseInt(ww.getText()) + "', '" + 
                    dd.getValue().toString() + "', '" + com.getText() + "')");

		    st.executeUpdate("insert into UsrCrt values('" + ii.getText() + "','" + id + "')");
                    con.close();

                } catch(java.sql.SQLException ex){
                    ex.printStackTrace();
                };
                
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("UniqueCode.fxml"));

            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene((Pane) loader.load()));

            UniqueCodeController controller = loader.<UniqueCodeController>getController();
            controller.initData(companyName,id);

            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();

            }
            catch(NumberFormatException | IOException e){
                FXMLLoader loader = new FXMLLoader(getClass().getResource("wrongFormatErrorMojavez.fxml"));

            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene((Pane) loader.load()));

            WrongFormatErrorMojavezController controller = loader.<WrongFormatErrorMojavezController>getController();
            controller.initData(companyName);

            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
            
            }
        }
    }
 
    @FXML
    private void logout(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FirstPage.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    }
    
    
     @Override
    public void initialize(URL url, ResourceBundle rb) {
       
     }  
    
    public void initData(String comp){
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from companies where name = '" + comp + "'");
            ArrayList<String> names=new ArrayList<String>();
            companyName=comp;
            while (rs.next()) {
                names.add(rs.getString("mojavez"));             
            }
            con.close();
            mojavezhaa.setItems(FXCollections.observableArrayList(names));

        } catch(java.sql.SQLException ex){
            
        }
        
    }
}
