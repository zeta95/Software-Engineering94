package softwareeng;

import java.io.IOException;
import static java.lang.System.console;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class RequiredMojavezsController implements Initializable {
    
    @FXML
    private Button enter;
    
    @FXML
    private TextArea ta;
    
    private ArrayList<String> reqCerts;
    private Ezhaarname ezhaar;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }   
    
    @FXML
    private void enter(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("enterRequiredMojavez.fxml"));

        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setScene(new Scene((Pane) loader.load()));

        EnterRequiredMojavezController controller = loader.<EnterRequiredMojavezController>getController();
        controller.initData(reqCerts,0,ezhaar);

        stage.show();

        ((Node)(event.getSource())).getScene().getWindow().hide();
    }
    
    public void initData(ArrayList<String> rc, Ezhaarname ez){
        ezhaar = ez;
        reqCerts = rc;
        for (String c: reqCerts){
            ta.appendText(c + "\n");
        }
    }
}
