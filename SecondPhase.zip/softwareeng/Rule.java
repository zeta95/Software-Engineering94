package softwareeng;

class Rule {
    private String iName;
    private String mName;
    private int minQuantity;
    private int maxQuantity;
    private String country;
    private int minPrice;
    private int maxPrice;
    private String fromDate;
    private String toDate;
    private String transType;
    private String company;
    private int minWeight;
    private int maxWeight;
    
    public Rule(String in,String mn,int minq,int maxq,String c,int minp,int maxp,String fDate,String tDate,String t,String com,int minw,int maxw){
      iName=in;
      mName=mn;
      minQuantity=minq;
      maxQuantity=maxq;
      country=c;
      minPrice=minp;
      maxPrice=maxp;
      fromDate=fDate;
      toDate=tDate;
      transType=t;
      company=com;
      minWeight=minw;
      maxWeight=maxw;
    }

}
