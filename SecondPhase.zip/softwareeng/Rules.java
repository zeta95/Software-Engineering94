package softwareeng;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import static softwareeng.UserRepo.CONN_STR;

public class Rules {
    
    public static ArrayList<String> getReqCertificates(Ezhaarname ez){
        ArrayList<String> res = new ArrayList<String>();
        
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select mname from rules where iname='" + ez.getItem().getName() + "' and (minweight='-1' or minweight<='" + ez.getItem().getWeight() + "') and (maxweight='-1' or maxweight>='" + ez.getItem().getWeight() + "') and (minquantity='-1' or minquantity<='" + ez.getQuantity() + "') and (maxquantity='-1' or maxquantity>='" + ez.getQuantity() + "') and (country='-1' or country='" + ez.getCountry() + "') and (minprice='-1' or minprice<='" + ez.getItem().getUnitPrice() + "') and (maxprice='-1' or maxprice>='" + ez.getItem().getUnitPrice() + "') and (fromdate='-1' or fromdate<='" + ez.getDate() + "') and (todate='-1' or todate>='" + ez.getDate() + "') and (transtype='-1' or transtype='" + ez.getTransType() + "')");
            System.out.println("select mname from rules where iname='" + ez.getItem().getName() + "' and (minweight='-1' or minweight<='" + ez.getItem().getWeight() + "') and (maxweight='-1' or maxweight>='" + ez.getItem().getWeight() + "') and (minquantity='-1' or minquantity<='" + ez.getQuantity() + "') and (maxquantity='-1' or maxquantity>='" + ez.getQuantity() + "') and (country='-1' or country='" + ez.getCountry() + "') and (minprice='-1' or minprice<='" + ez.getItem().getUnitPrice() + "') and (maxprice='-1' or maxprice>='" + ez.getItem().getUnitPrice() + "') and (fromdate='-1' or fromdate<='" + ez.getDate() + "') and (todate='-1' or todate>='" + ez.getDate() + "') and (transtype='-1' or transtype='" + ez.getTransType() + "')");
            while (rs.next()) {
                res.add(rs.getString("mname"));
            }
            
            con.close();
            return res;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return new ArrayList<String>();
        }
    }
    
    public static boolean isAppropriateCert(Ezhaarname ez, String certNum, String certName){
        
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date dateobj = new Date();
        String today = df.format(dateobj);
        
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from certificates where certid='" + certNum + "' and sid='" + ez.getSalesman().getID() + "' and name='" + certName + "' and item='" + ez.getItem().getName() + "' and quantity>='" + ez.getQuantity() + "' and transtype='" + ez.getTransType() + "' and country='" + ez.getCountry() + "' and weight>='" + ez.getItem().getWeight() + "' and duedate>='" + today + "' and company='" + ez.getItem().getCompany() + "'");
            System.out.println("select * from certificates where certid='" + certNum + "' and sid='" + ez.getSalesman().getID() + "' and name='" + certName + "' and item='" + ez.getItem().getName() + "' and quantity>='" + ez.getQuantity() + "' and transtype='" + ez.getTransType() + "' and country='" + ez.getCountry() + "' and weight>='" + ez.getItem().getWeight() + "' and duedate>='" + today + "' and company='" + ez.getItem().getCompany() + "'");
            if (rs.next()) {
                ez.addCert(certNum);
                con.close();
                return true;
            }
            
            con.close();
            return false;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return false;
        }
    }
}
