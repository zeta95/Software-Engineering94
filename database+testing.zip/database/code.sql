drop table users if exists
drop table mojusers if exists
drop table ezhaarnames if exists
drop table companies if exists
drop table salesman if exists
drop table certificates if exists
drop table UsrCrt if exists
drop table companieslist if exists
drop table rules if exists
drop table ezItems if exists;
drop table certItems if exists;
drop table ruleItems if exists;
drop table ruleCerts if exists;

create table users (
    username varchar(100) not null,
    password varchar(100) not null,
    type varchar(10) not null,
    primary key (username)
)

create table mojusers (
    username varchar(100) not null,
    company varchar(100) not null,
    primary key (username)
)

create table ezhaarnames(
    code integer not null,
    date varchar(10) not null,
    totalcost integer not null,
    sid integer not null,
    transType varchar(10) not null,
    country varchar(100) not null,
    primary key(code)
)

create table ezItems(
    code integer not null,
    iname varchar(100) not null,
    company varchar(100) not null,
    amount integer not null,
    amountUnit varchar(10) not null,
    unitPrice integer not null
)

create table companies (
    name varchar(100) not null,
    mojavez varchar(100) not null,
    primary key (name,mojavez)
)

create table salesman (
    name varchar(100) not null,
    family varchar(100) not null,
    id integer not null,
    primary key (id)
)

create table certificates (
    certID integer not null,
    dueDate varchar(100) not null,
    sid integer not null,
    name varchar(100) not null,
    transType varchar(10) not null,
    country varchar(100) not null,
    primary key (certID)
)

create table certItems(
    certID integer not null,
    iname varchar(100) not null,
    company varchar(100) not null,
    amount integer,
    amountUnit varchar(10),
    unitPrice integer
)

create table UsrCrt (
    sid integer not null,
    certID integer not null,
    primary key (certID)
)

create table companieslist (
    name varchar(100) not null,
    primary key(name)
)

create table rules(
   ruleId integer not null,
   fromDate varchar(100),
   toDate varchar(100),
   transType varchar(10) not null,
   country varchar(100) not null,
)

create table ruleItems(
   ruleId integer not null,
   iname varchar(100) not null,
   company varchar(100),
   minAmount integer,
   maxAmount integer,
   amountUnit varchar(10),
   minPrice integer,
   maxPrice integer,
   mintotalprice integer,
   maxtotalprice integer
)

create table ruleCerts(
   ruleId integer not null,
   mname varchar(100) not null,
   szmname varchar(100) not null,
   primary key(ruleId,mname)
)
