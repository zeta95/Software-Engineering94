package testingPackage;
/**
 *
 * @author zeta
 */
import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;
import softwareeng.CertItemPair;
import softwareeng.Ezhaarname;
import softwareeng.Item;
import softwareeng.Rules;
import softwareeng.Salesman;
public class ReqCertsTests{
    @Test
    public void reqCertsTest1(){ // no item
        ArrayList<Item> items = new ArrayList<Item>();
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        assertEquals( new ArrayList<CertItemPair>(), result);
    }
    
    @Test
    public void reqCertsTest2(){ // no rule for this item
        ArrayList<Item> items = new ArrayList<Item>();
        items.add(new Item("سبزی","",0,0,""));
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","land",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        assertEquals( new ArrayList<CertItemPair>(), result);
    }
    
    @Test
    public void reqCertsTest3(){ // rule for some items with no constraint
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("گندم","",0,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","land",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("سلامت محصولات غذایی","گندم"));
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest4(){ // rule for all items with no constraint
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("گندم","",0,0,"");
        Item item1 = new Item("برنج","",0,0,"");
        items.add(item);
        items.add(item1);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("سلامت محصولات غذایی","گندم"));
        expected.add(new CertItemPair("سلامت محصولات غذایی","برنج"));
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }

    @Test
    public void reqCertsTest5(){ // rule on unitPrice
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("بنزین","",9,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest6(){ // rule on unitPrice
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("بنزین","",21,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest7(){ // rule on unitPrice
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("بنزین","",15,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("واردات سوخت مایع","بنزین"));
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest8(){ // rule on unitPrice
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("بنزین","",10,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("واردات سوخت مایع","بنزین"));
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest9(){ // rule on unitPrice
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("بنزین","",20,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("واردات سوخت مایع","بنزین"));
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }

    @Test
    public void reqCertsTest10(){   //rule on ezDate in the range
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("سبزی","",0,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-06-03",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("سلامت محصولات غذایی","سبزی"));
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest11(){   //rule on company
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("","رنو",0,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-06-03",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("سلامت محصولات غذایی",""));
        expected.add(new CertItemPair("واردات خودرو خارجی",""));
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest12(){   //rule on ezDate on the lower bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("","رنو",0,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-06-01",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("سلامت محصولات غذایی",""));
        expected.add(new CertItemPair("واردات خودرو خارجی",""));
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest13(){   //rule on ezDate on the upper bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("","رنو",0,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-06-05",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("سلامت محصولات غذایی",""));
        expected.add(new CertItemPair("واردات خودرو خارجی",""));
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest14(){   //rule on ezDate lower than the lower bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("","رنو",0,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-05-15",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات خودرو خارجی",""));
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest15(){   //rule on ezDate higher than the upper bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("","رنو",0,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات خودرو خارجی",""));
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest16(){   //rule on amount in the bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,80,"kg");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest17(){   //rule on amount on the lower bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,12,"kg");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات سبک آلات","میلگرد"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest18(){   //rule on amount on the upper bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,100,"kg");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات سنگین آلات","میلگرد"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest19(){   //rule on amount lower than lower bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,10,"kg");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات سبک آلات","میلگرد"));
       
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest20(){   //rule on amount higher than the upper bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,1000,"kg");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات سنگین آلات","میلگرد"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }

    @Test
    public void reqCertsTest21(){ // rule for just one of items
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("گندم","",0,0,"");
        Item item1 = new Item("سبوس","",0,0,"");
        Item item2 = new Item("ماش","",0,0,"");
        items.add(item);
        items.add(item1);
        items.add(item2);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","land",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("سلامت محصولات غذایی","گندم"));
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTes22(){ // rule for country
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("نفت","",0,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"چین","land",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("واردات فراورده نفتی","نفت"));
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest23(){ // rule for transType: sea
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("حبوبات","",0,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","sea",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("سلامت محصولات غذایی","حبوبات"));
        expected.add(new CertItemPair("رطوبت سنجی محصول","حبوبات"));
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest24(){ // rule for transType: land
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("برنج","",0,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","land",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("سلامت محصولات غذایی","برنج"));
        expected.add(new CertItemPair("حمل و نقل زمینی","برنج"));
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest25(){ // rule for transType: air
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("برنج","",0,0,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","air",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        expected.add(new CertItemPair("سلامت محصولات غذایی","برنج"));
        expected.add(new CertItemPair("واردات هوایی","برنج"));
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }

    @Test
    public void reqCertsTest26(){   //rule on amount in the bound //tedad
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,80,"tedad");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest27(){   //rule on amount on the lower bound //tedad
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,12,"tedad");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات کم آلات","میلگرد"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest28(){   //rule on amount on the upper bound //tedad
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,100,"tedad");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات زیاد آلات","میلگرد"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest29(){   //rule on amount lower than lower bound //tedad
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,10,"tedad");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات کم آلات","میلگرد"));
       
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest30(){   //rule on amount higher than the upper bound //tedad
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,1000,"tedad");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات زیاد آلات","میلگرد"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest31(){   //rule on amount in the bound //kg
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,80,"kg");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest32(){   //rule on amount on the lower bound //kg
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,12,"kg");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات سبک آلات","میلگرد"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest33(){   //rule on amount on the upper bound //kg
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,100,"kg");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات سنگین آلات","میلگرد"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest34(){   //rule on amount lower than lower bound //kg
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,10,"kg");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات سبک آلات","میلگرد"));
       
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest35(){   //rule on amount higher than the upper bound //kg
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("میلگرد","",0,1000,"kg");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات سنگین آلات","میلگرد"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest36(){   //rule on totalVal lower than the lower bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("طلا","",1,9,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات ارزان قیمت","طلا"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest37(){   //rule on totalVal on the lower bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("طلا","",1,10,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات ارزان قیمت","طلا"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest38(){   //rule on totalVal in the bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("طلا","",1,500,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest39(){   //rule on totalVal on the higher bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("طلا","",1,1000000,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات گران قیمت","طلا"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
    @Test
    public void reqCertsTest40(){   //rule on totalVal higher than the upper bound
        ArrayList<Item> items = new ArrayList<Item>();
        Item item = new Item("طلا","",1,1000099,"");
        items.add(item);
        Ezhaarname ez = new Ezhaarname(1,"2016-08-23",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        /*for (int i=0; i<result.size();i++){
            System.out.println(result.get(i).getCert());
            System.out.println(result.get(i).getItem());
        }*/
        ArrayList<CertItemPair> expected = new ArrayList<CertItemPair>();
        
        expected.add(new CertItemPair("واردات گران قیمت","طلا"));
        
        assertEquals( expected.size(), result.size());
        for (int i=0; i<result.size(); i++){
            assertEquals( expected.get(i).getCert(), result.get(i).getCert());
            assertEquals( expected.get(i).getItem(), result.get(i).getItem());
        }
    }
    
}
