package testingPackage;

import java.util.ArrayList;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import softwareeng.CertItemPair;
import softwareeng.Ezhaarname;
import softwareeng.Item;
import softwareeng.Rules;
import softwareeng.Salesman;

/**
 *
 * @author zeta
 */
public class UpdateCertsTests {
    @Test
    public void reqCertsTest10(){ // no item
        ArrayList<Item> items = new ArrayList<Item>();
        Ezhaarname ez = new Ezhaarname(1,"",0,new Salesman(0,"0","0"),"","",items);
        ArrayList<CertItemPair> result = Rules.getReqCertificates(ez);
        assertEquals( new ArrayList<CertItemPair>(), result);
    }
}
