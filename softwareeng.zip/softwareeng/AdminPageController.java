package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author negar
 */
public class AdminPageController implements Initializable {
    
    @FXML
    private RadioButton ez;

    @FXML
    private RadioButton moj;

    @FXML
    private RadioButton air;
    
    @FXML
    private RadioButton land;
    
    @FXML
    private RadioButton sea;
            
    @FXML
    private Tab newRuleTab;
    
    @FXML
    private TextField username;
    
    @FXML
    private TextField passwrd;
    
    @FXML
    private DatePicker fromDate;

    @FXML
    private DatePicker toDate;

    @FXML
    private TextField country;
          
    @FXML
    private ChoiceBox mojCompany;
        
    @FXML
    private TextField newcompany;
    
    @FXML
    private TextField certName;
    
    @FXML
    private ChoiceBox userCompanyChoice;
    
    @FXML
    private TabPane tabP;

    private Rule rule=new Rule("-1","-1","-1",new ArrayList<ItemRule>(),new ArrayList<CertSaazman>());

    
 @FXML
    private void addUser(ActionEvent event) throws IOException {
        
        UserRepo repo=UserRepo.getRepo();    
        
        String s=username.getText();
        String p=passwrd.getText();
        String selectedCompany=(String)userCompanyChoice.getValue();

        String t="ez";
        if(ez.isSelected())
            t="ez";
        else if(moj.isSelected())
            t="moj";
      
        if (repo.addUser(s,p,t,selectedCompany)){
            Parent root = FXMLLoader.load(getClass().getResource("addSuccess.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
        } 
        else
        {
            Parent root = FXMLLoader.load(getClass().getResource("Error.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
        
    }
    
     @FXML
    private void addMojavez(ActionEvent event) throws IOException {
        
        UserRepo repo=UserRepo.getRepo();
        String selectedCompany=(String)mojCompany.getValue();
        Parent root;
        if(repo.getCompany(selectedCompany).addMojavez(certName.getText()))
            root = FXMLLoader.load(getClass().getResource("addMojavezSuccess.fxml"));
        else
            root = FXMLLoader.load(getClass().getResource("addMojavezRepeated.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
         
    }

    @FXML
    private void exitAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FirstPage.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    
    }
    
    @FXML
    private void addNewRule(ActionEvent event) throws IOException {
        UserRepo repo=UserRepo.getRepo();
        int id=repo.generateRuleId();
        rule.setCode(id);
        repo.addRule(rule);
        Parent root = FXMLLoader.load(getClass().getResource("addRuleSuccess.fxml"));

        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    
    }
    
    @FXML
    private void addNewCompany(ActionEvent event) throws IOException {
        UserRepo repo;
        Parent root;
        if(UserRepo.addCompany(newcompany.getText()))
            root = FXMLLoader.load(getClass().getResource("addCompanySuccess.fxml"));
        else
            root = FXMLLoader.load(getClass().getResource("addCompanyRepeated.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    
    }

    @FXML
    private void addCert(ActionEvent event) throws IOException {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("newCertRule.fxml"));

            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene((Pane) loader.load()));
            rule.setCountry(country.getText());
            rule.setTransType(air.isSelected()?"air":(land.isSelected()?"land":(sea.isSelected()?"sea":"")));
            rule.setFromDate(fromDate.getValue()==null?"":fromDate.getValue().toString());
            rule.setToDate(toDate.getValue()==null?"":toDate.getValue().toString());
            NewCertRuleController controller = loader.<NewCertRuleController>getController();
            controller.initData(rule);

            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
    
    }

    @FXML
    private void addItem(ActionEvent event) throws IOException {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("newItemRule.fxml"));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene((Pane) loader.load()));
            NewItemRuleController controller = loader.<NewItemRuleController>getController();
            rule.setCountry(country.getText());
            rule.setTransType(air.isSelected()?"air":(land.isSelected()?"land":(sea.isSelected()?"sea":"")));
            rule.setFromDate(fromDate.getValue()==null?"":fromDate.getValue().toString());
            rule.setToDate(toDate.getValue()==null?"":toDate.getValue().toString());
            controller.initData(rule);
            stage.show();    
            ((Node)(event.getSource())).getScene().getWindow().hide();
    
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        SingleSelectionModel<Tab> selectionModel = tabP.getSelectionModel();
        selectionModel.select(newRuleTab);
        UserRepo repo=UserRepo.getRepo();
        userCompanyChoice.setItems(FXCollections.observableArrayList(repo.getCompaniesNames()));
        mojCompany.setItems(FXCollections.observableArrayList(repo.getCompaniesNames()));
    } 

    public void initData(Rule r){
        rule=r;
        country.setText(r.getCountry());
        if (!r.getFromDate().equals(""))
            fromDate.setValue(LocalDate.parse(r.getFromDate()));
        if (!r.getToDate().equals(""))
            toDate.setValue(LocalDate.parse(r.getToDate()));
        
        if(r.getTransType().equals("air"))
            air.setSelected(true);
        else if (r.getTransType().equals("land"))
            land.setSelected(true);
        else if(r.getTransType().equals("sea"))
            sea.setSelected(true);
    }  
    
}
