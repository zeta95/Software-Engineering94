package softwareeng;

public class CertItemPair {
    private String cert;
    private String item;
    
    public CertItemPair(String c, String i){
        cert = c;
        item = i;
    }
    
    public String getCert(){
        return cert;
    }
    
    public String getItem(){
        return item;
    }
}
