package softwareeng;

public class CertSaazman {
    private String cert;
    private String saazman;
    
    public CertSaazman (String c, String s){
        cert = c;
        saazman = s;
    }
    
    public String getCert(){
        return cert;
    }
    
    public String getSaazman(){
        return saazman;
    }
}

