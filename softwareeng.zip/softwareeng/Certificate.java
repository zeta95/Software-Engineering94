package softwareeng;

import java.util.ArrayList;

public class Certificate {

    private final String name;
    private int uniqueCode;
    private final String dueDate;   
    private String country; 
    private String transType;
    private ArrayList<Item> items = new ArrayList<Item> ();

    public Certificate(String n , int uc,String dd , String c, String tt , ArrayList<Item> is){
        name = n;
        uniqueCode = uc;
        dueDate =dd;
        country=c;
        transType=tt;
        items=is;
    }
    
    public String getName(){
        return name;
    }

    public int getUniqueCode(){
        return uniqueCode;
    }

    public ArrayList<Item> getItems(){
        return items;
    } 
  
    public void setUniqueCode(int uc){
        uniqueCode = uc;
    }

    public String getCountry(){
        return country;
    }
    
    public String getTransType(){
        return transType;
    }

}