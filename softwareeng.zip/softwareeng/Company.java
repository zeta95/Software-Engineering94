package softwareeng;

import java.util.ArrayList;
import java.sql.*;

public class Company {
    private final String name;
    //private ArrayList<Certificate> mojavezes;
    
    public static final String CONN_STR = "jdbc:hsqldb:hsql://localhost";

    static {
	try {
            Class.forName("org.hsqldb.jdbc.JDBCDriver");
        } catch (ClassNotFoundException ex) {
            System.err.println("Unable to load HSQLDB JDBC driver");
	}
    }
    
    public Company(String n){
        name=n;
        //mojavezes=new ArrayList<Certificate>();
    }
    public String getName(){
        return name;
    }
    
    //public ArrayList<Certificate> getMojavezes(){
    //    return mojavezes;
    //}
    public boolean contains(String mojName){
        ArrayList<String> names = getMojavezesNames();
        for (String s: names )
            if(s.equals(mojName))
                return true;
        return false;
    }
    public ArrayList<String> getMojavezesNames(){
        //ArrayList<String> names=new ArrayList<String>();
        //for (Certificate m :mojavezes)
        //    names.add(m.getName());
        //return names;
        
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from companies where name='"+name+"'");
            ArrayList<String> names=new ArrayList<String>();
            while (rs.next()) {
                names.add(rs.getString("mojavez"));
            }
            con.close();
            return names;

        } catch(java.sql.SQLException ex){
            
            return new ArrayList<String>();
        }
    }
    
    public boolean addMojavez(String n){
        //for (Certificate c:mojavezes){
        //    if(n.equals(c.getName()))
        //        return false;
        //}
        //mojavezes.add(new Certificate (n));
        //return true;
        
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            st.executeUpdate("insert into companies values ('" + name + "','" + n + "')");
            con.close();
            return true;

        } catch(java.sql.SQLException ex){
            return false;
        }
    }
}
