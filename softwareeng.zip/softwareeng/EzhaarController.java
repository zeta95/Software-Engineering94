package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class EzhaarController implements Initializable {

    @FXML
    private DatePicker date;
        
    @FXML
    private TextField sid;
    
    @FXML
    private TextField sname;
    
    @FXML
    private TextField fname;
    
    @FXML
    private TextField country;
        
    @FXML
    private RadioButton air;
    
    @FXML
    private RadioButton land;
    
    @FXML
    private RadioButton sea;
    
    private Ezhaarname ezhaar;
    private ArrayList<Item> items=new ArrayList<Item>();
    
    @FXML
    private void addItem(ActionEvent event) throws IOException{
        if (!sid.getText().equals("") && !sname.getText().equals("") && !fname.getText().equals("") && date.getValue()!=null){
            UserRepo repo=UserRepo.getRepo();
            Salesman saleman=repo.findSaleman(Integer.parseInt(sid.getText()),sname.getText(),fname.getText());
            FXMLLoader loader = new FXMLLoader(getClass().getResource("newItem.fxml"));

            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene((Pane) loader.load()));

            NewItemController controller = loader.<NewItemController>getController();
            //controller.initData("e",items);

            int totalVal=0;
            for (Item i:items){
                totalVal+=i.getUnitPrice()*i.getAmount();
            }
            ezhaar=new Ezhaarname(0,date.getValue().toString(),totalVal,saleman,country.getText(),air.isSelected()?"air":(land.isSelected()?"land":(sea.isSelected()?"sea":"")),items);
            controller.initData("e",items);
            controller.initDataEz(ezhaar);

            stage.show();
            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
    }

    @FXML
    private void submitForm(ActionEvent event) throws IOException {
        UserRepo repo=UserRepo.getRepo();
        Salesman saleman;
        //Item item;
        
        if (date.getValue()==null || sname.getText().equals("") || fname.getText().equals("") || sid.getText().equals(""))  //#####
        {
            Parent root = FXMLLoader.load(getClass().getResource("emptyFieldError.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
        
            stage.setScene(scene);
            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
            
        }
        else
        {
            try{ ///default code e 0 midim be hameye ezhaarname haa avalesh 
                saleman=repo.findSaleman(Integer.parseInt(sid.getText()),sname.getText(),fname.getText());
                int totalVal=0;
                for (Item i:items){
                    totalVal+=i.getUnitPrice()*i.getAmount();
                }
                ezhaar=new Ezhaarname(0,date.getValue().toString(),totalVal,saleman,country.getText(),air.isSelected()?"air":(land.isSelected()?"land":(sea.isSelected()?"sea":"")),items);
                //int c,String d,int tval,Salesman sman,ArrayList<Item> is){
                //repo.addezhaarname(ez);// mojavez daar shod vaziat yek she
                //saleman.ezList.add(ez);

                FXMLLoader loader = new FXMLLoader(getClass().getResource("EzhaarnaamePreview.fxml"));

                Stage stage = new Stage(StageStyle.DECORATED);
                stage.setScene(new Scene((Pane) loader.load()));

                EzhaarnaamePreviewController controller = loader.<EzhaarnaamePreviewController>getController();
                controller.initData(ezhaar,items);

                stage.show();

                ((Node)(event.getSource())).getScene().getWindow().hide();
            }
            catch(NumberFormatException | IOException e){
                Parent root = FXMLLoader.load(getClass().getResource("wrongFormatError.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);
        
                stage.setScene(scene);
                stage.show();
            
                ((Node)(event.getSource())).getScene().getWindow().hide();
            }
        }
    }
    
    @FXML
    private void logout(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FirstPage.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    }
        
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void initData(Ezhaarname ez,ArrayList<Item> is){
        items=is;
        ezhaar = ez;
        //if (null != ez.getTransType())
            //       transType.setText("sea".equals(ez.getTransType())?"دریایی":("air".equals(ez.getTransType())?"هوایی":"زمینی"));
        //    date.setDate(ez.getDate());
        date.setValue(LocalDate.parse(ez.getDate()));
        sid.setText(Integer.toString(ez.getSalesman().getID()));
        sname.setText(ez.getSalesman().getName());
        fname.setText(ez.getSalesman().getFamily());
        country.setText(ez.getCountry());
        if(ez.getTransType().equals("sea"))
            sea.setSelected(true);
        else if(ez.getTransType().equals("air"))
            air.setSelected(true);
        else if(ez.getTransType().equals("land"))
            land.setSelected(true);
    }

}
