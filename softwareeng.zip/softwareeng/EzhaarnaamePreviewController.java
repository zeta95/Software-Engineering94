/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author zeta
 */
public class EzhaarnaamePreviewController implements Initializable {

    /**
     * Initializes the controller class.
     */

    @FXML
    private Text transType;
    
    @FXML
    private Text date;
        
    @FXML
    private Text sid;
    
    @FXML
    private Text sname;
    
    @FXML
    private Text sfamily;
    
    @FXML
    private Text country;
    
    @FXML
    private Text company;

    
    private static Ezhaarname ezhaar;
    private ArrayList<Item> items=new ArrayList<Item>();
    
    public static Ezhaarname getEz(){
        return ezhaar;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void showItems(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("showItems.fxml"));

        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setScene(new Scene((Pane) loader.load()));

        ShowItemsController controller = loader.<ShowItemsController>getController();
        controller.initData(ezhaar,items);

        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    }

    @FXML
    private void goPrev(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Ezhaar.fxml"));

        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setScene(new Scene((Pane) loader.load()));

        EzhaarController controller = loader.<EzhaarController>getController();
        controller.initData(ezhaar,items);

        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    }
    
     @FXML
    private void finalize(ActionEvent event) throws IOException {
        UserRepo repo=UserRepo.getRepo();
        
        
        //repo.addezhaarname(ezhaar);// mojavez daar shod vaziat yek she
        //repo.addEztoSalesman(ezhaar);
        
        ArrayList<CertItemPair> reqCerts = Rules.getReqCertificates(ezhaar);
        
        if (reqCerts.isEmpty()){
            int code = repo.finalizeEzhaar(ezhaar);

            FXMLLoader loader = new FXMLLoader(getClass().getResource("noCertReq.fxml"));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene((Pane) loader.load()));

            NoCertReqController controller = loader.<NoCertReqController>getController();
            controller.initData(code);

            stage.show();

            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
        
        else{
            FXMLLoader loader = new FXMLLoader(getClass().getResource("requiredMojavezs.fxml"));

            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene((Pane) loader.load()));

            RequiredMojavezsController controller = loader.<RequiredMojavezsController>getController();
            controller.initData(reqCerts,ezhaar);

            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
    }

    public void initData(Ezhaarname ez,ArrayList<Item> is){
        items=is;
        ezhaar = ez;
        date.setText(ez.getDate());
        sid.setText(Integer.toString(ez.getSalesman().getID()));
        sname.setText(ez.getSalesman().getName());
        sfamily.setText(ez.getSalesman().getFamily());
        transType.setText("sea".equals(ez.getTransType())?"دریایی":("air".equals(ez.getTransType())?"هوایی":("land".equals(ez.getTransType())?"زمینی":"")));
        country.setText(ez.getCountry());
        /*
        value.setText(Integer.toString(ez.getTotal()));
        item.setText(ez.getItem().getName());
        weight.setText(Integer.toString(ez.getItem().getWeight()));
        unitprice.setText(Integer.toString(ez.getItem().getUnitPrice()));
        company.setText(ez.getItem().getCompany());
        quantity.setText(Integer.toString(ez.getQuantity()));*/
    }
    
}
