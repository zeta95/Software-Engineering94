package softwareeng;

import java.util.ArrayList;

public class Ezhaarname {
    private int code;
    private String date;
    private int totalVal;
    private Salesman salesman;
    private String country;
    private String transType;
    private ArrayList<Item> items = new ArrayList<Item> ();
    private ArrayList<CertItemPair> usedCerts = new ArrayList<CertItemPair> (); // certs to be updated
    
    private int id;
    //dar hengaami ke be db ezafe mishavad(dar repo) bayad unique id ham set shvad
    
    public Ezhaarname(int c,String d,int tval,Salesman sman,String cnt,String tt,ArrayList<Item> is){
        code=c;
        date=d;
        salesman=sman;
        totalVal=tval;
        country=cnt;
        transType=tt;
        items=is;
    }
    
   // public void setType(String t){
   //     transType=t;
   // }
    
    public String getDate(){
        return date;
    }
    
    public int getTotal(){
        return totalVal;
    }
    
    public String getCountry(){
        return country;
    }
    
    public String getTransType(){
        return transType;
    }
        
    public Salesman getSalesman(){
        return salesman;
    }
    
    public ArrayList<Item> getItems(){
        return items;
    }
    
    public void setID(int i){ //////// tavasote repo call mishavad (dar zamani ke dar db add mishavad
        id = i;
    }
    
    public void addCert(CertItemPair certItemPair){
        usedCerts.add(certItemPair);
    }
    
    public void addItem(Item i){
        items.add(i);
    }
    
    public void emptyCerts(){
        usedCerts.clear();
    }
    
    public ArrayList<CertItemPair> getCertificates(){
        return usedCerts;
    }
    
    public int getCode(){
        return code;
    }
}
