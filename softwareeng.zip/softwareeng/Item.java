package softwareeng;

public class Item {
    private String name;
    private String company;
    private int unitPrice;
    private int amount;
    private String amountUnit;
    
    public Item(String n,String com,int up,int a,String au){
        name=n;
        company=com;
        unitPrice=up;
        amount=a;
        amountUnit=au;
    }
    
    public String getName(){
        return name;
    }
    
    public String getCompany(){
        return company;
    }
    
    public int getUnitPrice(){
        return unitPrice;
    }
        
    public int getAmount(){
        return amount;
    }
    
    public String getAmountUnit(){
        return amountUnit;
    }

}
