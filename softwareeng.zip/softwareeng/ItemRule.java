package softwareeng;

public class ItemRule extends Item{
    
    private int maxUnitPrice;
    private int maxAmount;
    private String maxAmountUnit;
    private int maxTotalPrice;
    private int minTotalPrice;
        //String n,String com,int up,int a,String au){
    public ItemRule (String n,String com,int up,int a,String au,int maxup,int maxa,String maxau,int maxtp,int mintp){
        super(n,com,up,a,au);
        maxUnitPrice=maxup;
        maxAmount=maxa;
        maxAmountUnit=maxau;
        maxTotalPrice=maxtp;
        minTotalPrice=mintp;
        
    }

    public int getMaxAmount(){
        return maxAmount;
    }

    public int getMaxUnitPrice(){
        return maxUnitPrice;
    }
    
    public int getMaxTotalPrice(){
        return maxTotalPrice;
    }
        
    public int getMinTotalPrice(){
        return minTotalPrice;
    }
        
}
