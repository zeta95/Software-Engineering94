package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class NewCertRuleController implements Initializable {

    private Rule rule;
    
    @FXML
    private ChoiceBox saazmaan;
    
    @FXML
    private TableView itemsTable;
    
    @FXML
    private TableColumn nameCol;

    @FXML
    private TableColumn szmCol;
    
    @FXML
    private TextField name;  
        
    public void addItem(ActionEvent event) throws IOException{
        UserRepo repo=UserRepo.getRepo();
        
        if (saazmaan.getValue()!=null && !name.getText().equals("")){
            if (UserRepo.getCompany(saazmaan.getValue().toString()).contains(name.getText())){
                //System.out.println("hehe");
        	rule.addCert(name.getText(),saazmaan.getValue().toString());
        	itemsTable.setItems(FXCollections.observableArrayList(rule.getCerts()));                        
            }
            else{
                Parent root = FXMLLoader.load(getClass().getResource("addRuleFail.fxml"));
        
                Stage stage = new Stage();
        	Scene scene = new Scene(root);
        	
        	stage.setScene(scene);
        	stage.show();
            }
        }
    }

    public void returnAction(ActionEvent event) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("adminPage.fxml"));

        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setScene(new Scene((Pane) loader.load()));

        AdminPageController controller = loader.<AdminPageController>getController();
        controller.initData(rule);
        
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	UserRepo repo=UserRepo.getRepo();
        saazmaan.setItems(FXCollections.observableArrayList(repo.getCompaniesNames()));
    } 

    public void initData(Rule r){
    	rule=r;
        
        nameCol.setCellValueFactory(
                new PropertyValueFactory<CertSaazman,String>("cert"));
        szmCol.setCellValueFactory(
                new PropertyValueFactory<CertSaazman,String>("saazman")); 

        itemsTable.setItems(FXCollections.observableArrayList(r.getCerts()));
                
    }    
    
}
