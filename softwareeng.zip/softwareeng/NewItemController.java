package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author negar
 */
public class NewItemController implements Initializable {
    
    @FXML
    private TableView itemsTable;
    
    @FXML
    private TableColumn nameCol;

    @FXML
    private TableColumn amountCol;     
    
    @FXML
    private TableColumn unitPriceCol;    
    
    @FXML
    private TableColumn companyCol;       
    
    @FXML
    private Text totalVal; 
    
    @FXML
    private ChoiceBox unitChoice; 
    
    @FXML
    private TextField company;   
    
    @FXML
    private TextField itemName;   
    
    @FXML
    private TextField itemAmount;  
    
    @FXML
    private TextField unitPrice; 
        
    String passedComp="";
    String selectedMojavez="";
    int sid;
    String dd="";
    String country="";
    String transType="";

    
    ArrayList<Item> items=new ArrayList<Item>();
    String type="";
    Ezhaarname passedEz;
    
    public void addItem(ActionEvent event) throws IOException{
        //UserRepo repo=UserRepo.getRepo();
        if ((type.equals("e") && !itemName.getText().equals("") && !itemAmount.getText().equals("") && unitChoice.getValue()!=null) || type.equals("c")){
            Item newitem=new Item(itemName.getText(),company.getText(),unitPrice.getText().equals("")?-1:Integer.parseInt(unitPrice.getText()),itemAmount.getText().equals("")?-1:Integer.parseInt(itemAmount.getText()),unitChoice.getValue()==null?"":(String)unitChoice.getValue());
            items.add(newitem);
            itemsTable.setItems(FXCollections.observableArrayList(items));
            int totalValue=0;
            for (Item i:items){
                totalValue+=i.getAmount()*i.getUnitPrice();
            }
            totalVal.setText(Integer.toString(totalValue));
        }
    }
    
    public void returnAction(ActionEvent event) throws IOException{
        FXMLLoader loader=new FXMLLoader();
        if (type.equals("e")){
            loader = new FXMLLoader(getClass().getResource("Ezhaar.fxml"));
        }
        else if (type.equals("c")){
            loader = new FXMLLoader(getClass().getResource("Niloomojavez.fxml"));
        }

        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setScene(new Scene((Pane) loader.load()));
        if (type.equals("e")){
            EzhaarController controller = loader.<EzhaarController>getController();
            controller.initData(passedEz,items);
        }
        else if (type.equals("c")){
            NiloomojavezController controller = loader.<NiloomojavezController>getController();
            controller.initData(items,passedComp,selectedMojavez,sid,dd,country,transType);
        }
        
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }   
    
    public void initData(String t,ArrayList<Item> is){
        type=t;
        items=is;
        ArrayList <String> units=new ArrayList<String>();
        units.add("kg");
        units.add("tedad");
        unitChoice.setItems(FXCollections.observableArrayList(units));
        nameCol.setCellValueFactory(
                new PropertyValueFactory<Item, String>("name"));
 
        amountCol.setCellValueFactory(
                new PropertyValueFactory<Item, Integer>("amount"));
        
        unitPriceCol.setCellValueFactory(
                new PropertyValueFactory<Item, Integer>("unitPrice")); 
        
        companyCol.setCellValueFactory(
                new PropertyValueFactory<Item, String>("company")); 
        
        itemsTable.setItems(FXCollections.observableArrayList(items));
        int totalValue=0;
        for (Item i:is){
            totalValue+=i.getAmount()*i.getUnitPrice();
        }
        totalVal.setText(Integer.toString(totalValue));
       
    }
    public void initDataCert(String comp,String selectedCert,int ii,String duedate,String c,String tt){
        passedComp=comp;
        selectedMojavez=selectedCert;
        sid=ii;
        dd=duedate;
        country=c;
        transType=tt;
    }
    
    public void initDataEz(Ezhaarname ez){
        passedEz=ez;
        dd=ez.getDate();
        sid=ez.getSalesman().getID();
        country=ez.getCountry();
        transType=ez.getTransType();
        
        
    }
}
