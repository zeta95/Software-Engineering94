package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author negar
 */
public class NewItemRuleController implements Initializable {

    @FXML
    private TableView itemsTable;
    
    @FXML
    private TableColumn nameCol;

    @FXML
    private TableColumn minAmountCol;     
    
    @FXML
    private TableColumn maxAmountCol; 
    
    @FXML
    private TableColumn minUnitPriceCol; 
    
    @FXML
    private TableColumn maxUnitPriceCol; 
    
    @FXML
    private TableColumn minTotalPriceCol; 
    
    @FXML
    private TableColumn maxTotalPriceCol;
    
    @FXML
    private TableColumn companyCol;       
            
    @FXML
    private ChoiceBox unitChoice; 
    
    @FXML
    private TextField company;   
    
    @FXML
    private TextField itemName;   
    
    @FXML
    private TextField minItemAmount;  
    
    @FXML
    private TextField maxItemAmount;  
    
    @FXML
    private TextField minUnitPrice; 
    
    @FXML
    private TextField maxUnitPrice; 
    
    @FXML
    private TextField maxTotalPrice; 
    
    @FXML
    private TextField minTotalPrice; 
    
    private Rule rule;

    public void addItem(ActionEvent event) throws IOException{
        UserRepo repo=UserRepo.getRepo();
        ItemRule newitem=new ItemRule(itemName.getText(),company.getText(),minUnitPrice.getText().equals("")?-1:Integer.parseInt(minUnitPrice.getText()),minItemAmount.getText().equals("")?-1:Integer.parseInt(minItemAmount.getText()),unitChoice.getValue()==null?"":(String)unitChoice.getValue(),maxUnitPrice.getText().equals("")?-1:Integer.parseInt(maxUnitPrice.getText()),maxItemAmount.getText().equals("")?-1:Integer.parseInt(maxItemAmount.getText()),unitChoice.getValue()==null?"":(String)unitChoice.getValue(),maxTotalPrice.getText().equals("")?-1:Integer.parseInt(maxTotalPrice.getText()),minTotalPrice.getText().equals("")?-1:Integer.parseInt(minTotalPrice.getText()));
        rule.addItem(newitem);
        itemsTable.setItems(FXCollections.observableArrayList(rule.getItems()));       
    }

    public void returnAction(ActionEvent event) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("adminPage.fxml"));

        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setScene(new Scene((Pane) loader.load()));

        AdminPageController controller = loader.<AdminPageController>getController();
        controller.initData(rule);
        
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 

    public void initData(Rule r){
    	rule=r;
    	ArrayList <String> units=new ArrayList<String>();
        units.add("kg");
        units.add("tedad");
        unitChoice.setItems(FXCollections.observableArrayList(units));
        unitChoice.setItems(FXCollections.observableArrayList(units));
        nameCol.setCellValueFactory(
                new PropertyValueFactory<ItemRule, String>("name"));
 
        minAmountCol.setCellValueFactory(
                new PropertyValueFactory<ItemRule, Integer>("amount"));

        maxAmountCol.setCellValueFactory(
                new PropertyValueFactory<ItemRule, Integer>("maxAmount"));
        
        minUnitPriceCol.setCellValueFactory(
                new PropertyValueFactory<ItemRule, Integer>("unitPrice")); 

        maxUnitPriceCol.setCellValueFactory(
                new PropertyValueFactory<ItemRule, Integer>("maxUnitPrice"));
        
        minTotalPriceCol.setCellValueFactory(
                new PropertyValueFactory<ItemRule, Integer>("minTotalPrice")); 

        maxTotalPriceCol.setCellValueFactory(
                new PropertyValueFactory<ItemRule, Integer>("maxTotalPrice")); 

        companyCol.setCellValueFactory(
                new PropertyValueFactory<ItemRule, String>("company")); 
        
        itemsTable.setItems(FXCollections.observableArrayList(r.getItems()));

    }   
    
}
