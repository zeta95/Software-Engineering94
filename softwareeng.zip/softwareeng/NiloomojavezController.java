package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import static softwareeng.UserRepo.CONN_STR;

/**
 * FXML Controller class
 *
 * @author Niloofar.Sh
 */
public class NiloomojavezController implements Initializable {
    
    @FXML
    private ChoiceBox mojavezhaa ;
              
    @FXML
    private TextField ii;
    
    @FXML
    private TextField country;
        
    @FXML
    private RadioButton air;
    
    @FXML
    private RadioButton land;
    
    @FXML
    private RadioButton sea;
        
    @FXML
    private DatePicker dd;
    
    private String companyName;
    private ArrayList<String> certs;
    private ArrayList<Item> items=new ArrayList <Item>();
    
    
    @FXML
    private void addItem(ActionEvent event) throws IOException {
        
        if (mojavezhaa.getValue()!=null && !ii.getText().equals("")){

            FXMLLoader loader = new FXMLLoader(getClass().getResource("newItem.fxml"));

            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene((Pane) loader.load()));

            NewItemController controller = loader.<NewItemController>getController();
            controller.initData("c",items);
            controller.initDataCert(companyName,(String)mojavezhaa.getValue(),Integer.parseInt(ii.getText()),dd.getValue()==null?"":dd.getValue().toString(),country.getText(),air.isSelected()?"air":(land.isSelected()?"land":(sea.isSelected()?"sea":"")));

            stage.show();
            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
    }
    
    
    @FXML
    private void submitForm(ActionEvent event) throws IOException {
        UserRepo repo=UserRepo.getRepo();      
        int id=repo.generateCertId();
        
        if (!ii.getText().equals("") && mojavezhaa.getValue()!=null && id!=-1){
                     
            try{
                Connection con = DriverManager.getConnection(CONN_STR);
                Statement st = con.createStatement();
                st.executeUpdate("insert into certificates values ('" + id +"', '" + (dd.getValue()==null?"":dd.getValue().toString()) + "', '" + ii.getText()
                 + "', '" + (String)mojavezhaa.getValue() + "', '" + (air.isSelected()?"air":(land.isSelected()?"land":(sea.isSelected()?"sea":""))) + "', '" + country.getText() + "')");
                    //sertId,dudate,sid,name
                for (Item i:items){
                    repo.addCertItem(id, i);
                }

                st.executeUpdate("insert into UsrCrt values('" + ii.getText() + "','" + id + "')");
                con.close();

            } catch(java.sql.SQLException ex){
                System.out.println("certificates,usrcrt");
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource("UniqueCode.fxml"));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene((Pane) loader.load()));
            UniqueCodeController controller = loader.<UniqueCodeController>getController();
            controller.initData(companyName,id);
            stage.show();
            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
    }
 
    @FXML
    private void logout(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FirstPage.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
            
        ((Node)(event.getSource())).getScene().getWindow().hide();
    }
    
    
     @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }  
    
    public void initData(ArrayList<Item> is,String comp,String selectedCert,int sid,String duedate,String c,String tt){
        companyName=comp;
        UserRepo repo=UserRepo.getRepo(); 
        mojavezhaa.setItems(FXCollections.observableArrayList(repo.getCerts(comp)));
        items=is;
        if(sid!=0)
            ii.setText(Integer.toString(sid));
        if (!selectedCert.equals(""))
            mojavezhaa.setValue(selectedCert);
        if (!duedate.equals(""))
        dd.setValue(LocalDate.parse(duedate));
        country.setText(c);
        if(tt.equals("air"))
            air.setSelected(true);
        else if (tt.equals("land"))
            land.setSelected(true);
        else if(tt.equals("sea"))
            sea.setSelected(true);
    }
}
