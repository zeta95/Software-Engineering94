package softwareeng;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class Rule {
    private int code=0;
    private String country;
    private String transType;
    private String company;
    private String fromDate;
    private String toDate;
    private ArrayList<ItemRule> items = new ArrayList<ItemRule> ();
    private ArrayList<CertSaazman> certs = new ArrayList<CertSaazman>();
   
    //fromdate o todate o code set nashodn
    public Rule(String c,String t,String com,ArrayList<ItemRule> is,ArrayList<CertSaazman> cns){
      country=c;
      transType=t;
      company=com;
      items=is;
      certs=cns;
    }

    public void addItem(ItemRule i){
      items.add(i);
    }

    public void addCert(String c,String s){
      certs.add(new CertSaazman(c,s));
    }

    public void setItems(ArrayList<ItemRule> is){
      items=is;
    }

    public void setCerts(ArrayList<CertSaazman> cs){
      certs=cs;
    }

    public ArrayList<ItemRule> getItems(){
      return items;
    }

    public ArrayList<CertSaazman> getCerts(){
      return certs;
    }

    public void setCountry(String c){
      country=c;
    }

    public void setTransType(String tt){
      transType=tt;
    }

    public void setCompany(String c){
      company=c;
    }

    public void setCode(int c){
      code=c;
    }

    public void setFromDate(String fd){
      fromDate=fd;
    }

    public void setToDate(String td){
      toDate=td;
    }

    public int getCode(){
      return code;
    }

    public String getCompany(){
      return company;
    }
    public String getCountry(){
      return country;
    }
    public String getTransType(){
      return transType;
    }
    public String getFromDate(){
      return fromDate;
    }
    public String getToDate(){
      return toDate;
    }
}
