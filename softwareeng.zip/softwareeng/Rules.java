package softwareeng;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import static softwareeng.UserRepo.CONN_STR;

public class Rules {
    
    public static ArrayList<CertItemPair> getReqCertificates(Ezhaarname ez){
        ArrayList<CertItemPair> res = new ArrayList<CertItemPair>();
        
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            
            for (Item i:ez.getItems()){
                ResultSet rs;
                //if (i.getAmountUnit().equals("kg")){        //aval tu  jadvale rule items begarde shomare ghanuno peida kne bad tu ruleCerts begarde certiface to bege
                 rs = st.executeQuery("select * from rules where (fromdate='' or fromdate<='" + ez.getDate() + "') and (todate='' or todate>='" + ez.getDate() + "') and (transType='' or transType='" + ez.getTransType() + "') and (country='' or country='" + ez.getCountry() + "')");
                
                //}
                //else
                //    rs = st.executeQuery("select mname from ruleItems where iname='" + i.getName() + "' and (minamount='-1' or minamount<='" + i.getAmount() + "') and (maxquantity='-1' or maxquantity>='" + i.getAmount() + "') and (minprice='-1' or minprice<='" + i.getUnitPrice() + "') and (maxprice='-1' or maxprice>='" + i.getUnitPrice() + "') and (fromdate='-1' or fromdate<='" + ez.getDate() + "') and (todate='-1' or todate>='" + ez.getDate() + "')");
                while (rs.next()) {
                    int totalVal=(i.getAmount()*i.getUnitPrice());
                    
                    ResultSet rs2 = st.executeQuery("select * from ruleItems where ruleid='"+rs.getString("ruleid")+"' and (iname='' or iname='" + i.getName() + "') and (minamount='-1' or minamount<='" + i.getAmount() + "') and (maxamount='-1' or maxamount>='" + i.getAmount() + "') and (minprice='-1' or minprice<='" + i.getUnitPrice() + "') and (maxprice='-1' or maxprice>='" + i.getUnitPrice() + "') and (company='' or company='" + i.getCompany() + "') and (amountunit='' or amountunit='"+i.getAmountUnit() + "') and (mintotalprice='-1' or mintotalprice<='"+ totalVal + "') and (maxtotalprice='-1' or maxtotalprice>='"+ totalVal +"')");
                    while (rs2.next()) {
                        ResultSet rs3 = st.executeQuery("select * from ruleCerts where ruleid='" + rs2.getString("ruleid") + "'");/////////// :?
                        if (rs3.next())
                            res.add(new CertItemPair(rs3.getString("mname"),i.getName()));
                    }
                    
                    rs2 = st.executeQuery("select * from ruleItems where ruleid='"+rs.getString("ruleid")+"'");
                    if (!rs2.next()){
                        ResultSet rs3 = st.executeQuery("select * from ruleCerts where ruleid='" + rs.getString("ruleid") + "'");/////////// :?
                        if (rs3.next())
                            res.add(new CertItemPair(rs3.getString("mname"),i.getName()));
                    }
                }
            }
            
            con.close();
            return res;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return new ArrayList<CertItemPair>();
        }
    }
    
    public static boolean isAppropriateCert(Ezhaarname ez, String certNum, String certName, String itemName){
        
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date dateobj = new Date();
        String today = df.format(dateobj);
        
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from certificates where certid='" + certNum + "' and sid='" + ez.getSalesman().getID() + "' and name='" + certName + "' and duedate>='" + today + "'");
            ResultSet rss;
            while (rs.next()) { 
                for (Item i:ez.getItems()){
                    if (i.getName().equals(itemName)){
                        rss = st.executeQuery("select * from certItems where certid='" + rs.getInt("certid") + "' and (iname='' or iname='" + i.getName() + "') and (company='' or company='" + i.getCompany() +  "') and (amount='-1' or amount='" + i.getAmount() +  "') and (amountUnit='' or amountUnit='" + i.getAmountUnit() +  "') and (unitPrice='-1' or unitPrice='" + i.getUnitPrice() + "')");
                        if (rss.next()){
                            ez.addCert(new CertItemPair(certNum,itemName));
                            con.close();
                            return true;
                        }
                    }
                }
            }
            
            con.close();
            return false;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return false;
        }
    }
}
