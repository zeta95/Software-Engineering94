package softwareeng;

public class Salesman {
    private final int id;
    private final String name;
    private final String family;
    
    //public ArrayList<Ezhaarname> ezList;
    
    public Salesman(int i,String n,String f){
        //ezList=new ArrayList<Ezhaarname>();
        id=i;
        name=n;
        family=f;
    }
    
    public int getID(){
        return id;
    }
    
    public String getName(){
        return name;
    }
    
    public String getFamily(){
        return family;
    }
}
