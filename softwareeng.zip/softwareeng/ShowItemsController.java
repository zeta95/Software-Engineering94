/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author negar
 */
public class ShowItemsController implements Initializable {

    @FXML
    private TableView itemsTable;
    
    @FXML
    private TableColumn nameCol;

    @FXML
    private TableColumn amountCol;     
    
    @FXML
    private TableColumn unitPriceCol;    
    
    @FXML
    private TableColumn companyCol;

    @FXML
    private Text totalVal;

    private Ezhaarname ezhaar;
    private ArrayList<Item> items=new ArrayList<Item>();
    
    @FXML
    private void okAction(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("EzhaarnaamePreview.fxml"));
        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setScene(new Scene((Pane) loader.load()));

        EzhaarnaamePreviewController controller = loader.<EzhaarnaamePreviewController>getController();
        controller.initData(ezhaar,items);

        stage.show();

        ((Node)(event.getSource())).getScene().getWindow().hide();
        
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
 
    }  

    public void initData(Ezhaarname ez,ArrayList<Item> is){
        items=is;
        ezhaar = ez;
        nameCol.setCellValueFactory(
                new PropertyValueFactory<Item, String>("name"));
 
        amountCol.setCellValueFactory(
                new PropertyValueFactory<Item, Integer>("amount"));
        
        unitPriceCol.setCellValueFactory(
                new PropertyValueFactory<Item, Integer>("unitPrice")); 
        
        companyCol.setCellValueFactory(
                new PropertyValueFactory<Item, String>("company")); 
        
        itemsTable.setItems(FXCollections.observableArrayList(items));
        int totalValue=0;
        for (Item i:items){
            totalValue+=i.getAmount()*i.getUnitPrice();
        }
        totalVal.setText(Integer.toString(totalValue));
    }
}
