package softwareeng;

public class User {
    private final String username;
    private final String password;
    private final String type;
    public User (String u, String p,String t){
        username=u;
        password=p;
        type=t;
    }
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }
    
    public String getType(){
        return type;
    }
    
}
