package softwareeng;

import java.util.*;
import java.sql.*;

/*

create table users (
    username varchar(100) not null,
    password varchar(100) not null,
    type varchar(10) not null
    primary key (username)
)

*/

/*

create table mojusers (
    username varchar(100) not null,
    company varchar(100) not null
    primary key (username)
)

*/

/*

crate table ezhharnames(
    date varchar(10) not null,
    totalcost integer not null,
    country varchar(100) not null,
    transType varchar(4) not null,
    quantity integer not null,
    sid integer not null,
    status boolean not null,
    iname varchar(100) not null,
    icompany varchar(100) not null,
    iweight integer not null,
    iunitPrice integer not null
)
*/

public class UserRepo {
    
   /* private static ArrayList<User> users;
    private static ArrayList<Salesman> salemans;
    private static ArrayList<Ezhaarname> ezhaarnameList;*/
    //private static Rules rules=new Rules();
    private static UserRepo repo;
    /*private static ArrayList<Company> companies;*/
    
    public static final String CONN_STR = "jdbc:hsqldb:hsql://localhost";

    static {
	try {
            Class.forName("org.hsqldb.jdbc.JDBCDriver");
        } catch (ClassNotFoundException ex) {
            System.err.println("Unable to load HSQLDB JDBC driver");
	}
    }
    
    private UserRepo(){
        /*users = new ArrayList<User>();
        salemans= new ArrayList<Salesman>();
        ezhaarnameList= new ArrayList<Ezhaarname>();
        users.add(new User("admin","1234","admin"));
        rules=new Rules();
        companies= new ArrayList<Company>();*/
        //companies.add(new Company("غذا")); //paaak kn
        //companies.add(new Company("نفت"));
        //companies.add(new Company("پوشاک"));
    }
    
    public static UserRepo getRepo(){
        if (repo==null){
            repo=new UserRepo();
        }
        return repo;
    }
    public boolean isAdmin(String un,String pw){
        if(un.equals("admin"))
            if(pw.equals("1234"))
                return true;
        return false;
    }
    public boolean isValidUser(String un,String pw){
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from users where username = '" + un + "' and password = '" + pw + "'");
            if (rs.next()) {
                con.close();
                return true;
            }
            con.close();
            return false;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return false;
        }
        //return users.stream().anyMatch((u) -> (u.getUsername().equals(un) && u.getPassword().equals(pw)));
    }

    public boolean isEzUser(String un,String pw){
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from users where username = '" + un + "' and password = '" + pw + "' and type = 'ez'");
            if (rs.next()) {
                con.close();
                return true;
            }

            con.close();
            return false;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return false;
        }
                
        /*if (users.stream().anyMatch((u) -> ("ez".equals(u.getType())))) {
            return true;
        }
        else
            return false;*/
        
    }
    
    public boolean isMojUser(String un,String pw){
       /* if (users.stream().anyMatch((u) -> ("moj".equals(u.getType())))) {
            return true;
        }
        else
            return false;*/
       try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from users where username = '" + un + "' and password = '" + pw + "' and type='moj'");
            
            if (rs.next()) {
                con.close();
                return true;
            }

            con.close();
            return false;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return false;
        }
        
    }
    
    public Salesman findSaleman(int id,String name,String fname){
        /*for (Salesman sm:salemans){
            if(sm.getID()==id){
                return sm;
            }
        }
        return new Salesman(id,name,fname);*/
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from salesman where id ='" + id + "'");
            if (rs.next()) {
                Salesman salesman = new Salesman(rs.getInt("id"),rs.getString("name"),rs.getString("family"));
                con.close();
                return salesman;
            }

            con.close();
            return new Salesman(id,name,fname);

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return null;
        }
        
    }
    
    public boolean addUser(String un,String pw,String t,String c){
        //if (users.stream().anyMatch((u) -> (u.getUsername().equals(un))))
        //    return false;
        //users.add(new User(un,pw,t));
        //return true;

        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from users where username = '" + un + "'");
            
            if (rs.next()) {
                con.close();
                return false;
            }
            st.executeUpdate( "insert into users values ('" + un + "', '"+ pw + "','"+ t + "')");
            if (t.equals("moj")){
                st.executeUpdate("insert into mojusers values ('"+un + "', '"+ c + "')");
            }
            con.close();
            return true;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return false;
        }
    }
    
    private int getCode(){
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select max(code) as max_code from ezhaarnames");
            int maxId = 0;
            if (rs.next()) {
                    maxId = rs.getInt("max_code");
            }
            
            if (maxId == 0){
                return 10000;
            }
            con.close();
            return maxId + 1;
        }catch(java.sql.SQLException ex){
                ex.printStackTrace();
                return -1;
        }
    }
    
    
    public int addezhaarname(Ezhaarname ez){
        //ezhaarnameList.add(ez); 
        try{
            int ezCode = getCode();
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            st.executeUpdate("insert into ezhaarnames values ('" + ezCode + "', '" + ez.getDate() + "', '" + 
                    ez.getTotal() + "', '" + ez.getSalesman().getID() + "', '" + ez.getTransType() + "', '" + ez.getCountry() + "')");
            for (Item i:ez.getItems()){
                st.executeUpdate("insert into ezItems values ('" + ezCode + "', '" + i.getName() +
                        "', '" + i.getCompany() + "', '" + i.getAmount() + "', '" + i.getAmountUnit() + "', '" + i.getUnitPrice() + "')");
             
            }       
            con.close();
            return ezCode;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return -1;
        }
    }
    
    //public void addEztoSalesman(Ezhaarname ezhaar){
    //    Salesman s = ezhaar.getSalesman();
    //    s.ezList.add(ezhaar);
    //}
    
    //public static Rules getRules(){
    //    return rules;
    //}
    
    public static boolean addCompany(String name){
        
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from companieslist where name = '" + name + "'");
            
            if (rs.next()) {
                con.close();
                return false;
            }
            st.executeUpdate( "insert into companieslist values ('" + name + "')");
            con.close();
            return true;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return false;
        }
    }
    
    public static ArrayList<Company> getCompanies(){
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from companieslist");
            
            ArrayList<Company> res = new ArrayList<Company>();
            
            while (rs.next()) {
                res.add(new Company(rs.getString("name")));
            }
            
            con.close();
            return res;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return new ArrayList<Company>();
        }
    }
    
    public static ArrayList<String> getCompaniesNames(){
        ArrayList<String> names=new ArrayList<String>();
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from companieslist");
            
            while (rs.next()) {
                names.add(rs.getString("name"));
            }
            
            con.close();
            return names;

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return new ArrayList<String>();
        }
    }
    
    public static Company getCompany(String name){
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from companieslist where name = '" + name + "'");
            
            if (rs.next()) {
                String n = rs.getString("name");
                con.close();
                return new Company(n);
            }
            
            con.close();
            return new Company("");

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return new Company("");
        }
    }
    
    public int finalizeEzhaar(Ezhaarname ez){
        updateUsedCerts(ez);
        return addezhaarname(ez);
    }
    
    public void updateUsedCerts(Ezhaarname ez){ // ke az meghdareshoon kam she
        ArrayList<CertItemPair> certs = ez.getCertificates();
        
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs;
//update users set amount = ..con. where id = 

            for (CertItemPair certItem: certs){
                rs = st.executeQuery("select amount from certItems where certid = '" + certItem.getCert() + "'");
                if (rs.next())
                    for (Item i:ez.getItems()){
                        if (i.getName().equals(certItem.getItem()))
                            if (rs.getInt("amount") != -1)
                                st.executeUpdate("update certItem set amount ='" + (rs.getInt("amount")-i.getAmount()) + "' where certid = '" + certItem.getCert() + "' and iname='" + i.getName() + "'");
                    }
                  
            }
            con.close();

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
        }
    }
    
    public int generateCertId(){
        
        try{
      Connection con = DriverManager.getConnection(CONN_STR);
      Statement st = con.createStatement();
      ResultSet rs = st.executeQuery("select max(certID) as max_code from certificates");
      int maxId =0;
      if (rs.next()) {
        maxId = rs.getInt("max_code");
      }
      if (maxId==0)
          return 10000;
      con.close();
      return maxId + 1;
    }catch(java.sql.SQLException ex){
      ex.printStackTrace();
      return -1;
    }

    }

    public int generateRuleId(){
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select max(ruleID) as max_code from rules");
            int maxId =0;
            if (rs.next()) {
              maxId = rs.getInt("max_code");
            }
            con.close();
            return maxId + 1;
        }catch(java.sql.SQLException ex){
            ex.printStackTrace();
            return -1;
        }
    }
    
    public String getUserCompany(String u){
         try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from mojusers where username = '" + u + "'");
            String compName="";
            if (rs.next()) {
                compName=rs.getString("company");             
            }
            con.close();
            return compName;

        } catch(java.sql.SQLException ex){
            return "";
        }
    }
    
    public static void addRule(Rule r){
        //rules.add(new Rule(in,mn,minq,maxq,c,minp,maxp,fDate,tDate,t,com,minw,maxw));
        
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            st.executeUpdate("insert into rules values ('" + Integer.toString(r.getCode()) +"' , '" +r.getFromDate()+"' , '" +r.getToDate()+"' , '" +
                    r.getTransType()+"' , '" +r.getCountry()+ "')");
            
            for(ItemRule ir:r.getItems()){
            st.executeUpdate("insert into ruleItems values ('" + Integer.toString(r.getCode()) +"' , '" +ir.getName()+"' , '" +ir.getCompany()+"' , '" +
                    ir.getAmount()+"' , '" +ir.getMaxAmount()+"' , '" +ir.getAmountUnit()+"' , '" +ir.getUnitPrice()+"' , '" +ir.getMaxUnitPrice() +"' , '" +ir.getMinTotalPrice()+"' , '" +ir.getMaxTotalPrice()+"')");
            }
            
            for(CertSaazman cs:r.getCerts()){
             st.executeUpdate("insert into ruleCerts values ('" + Integer.toString(r.getCode()) +"' , '" + cs.getCert() +"' , '" + cs.getSaazman() +"')");
                    
            }
                       
            con.close();

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
        }
        
    }

    public void addEzItem(int code,Item i){
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            st.executeUpdate("insert into ezItems values ('" + code +"' , '" +i.getName()+"' , '" +
                   i.getCompany()+"' , '" +i.getAmount()+"' , '" +i.getAmountUnit()+"' , '" +i.getUnitPrice()+"')");

            con.close();

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
        }

    }
    
    public void addCertItem(int code,Item i){
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            st.executeUpdate("insert into certItems values ('" + code +"' , '" +i.getName() 
                    +"' , '" +i.getCompany()+"' , '" +i.getAmount()+"' , '" +i.getAmountUnit()+"' , '" +i.getUnitPrice()+"')");

            con.close();

        } catch(java.sql.SQLException ex){
            ex.printStackTrace();
        }

    }

    public ArrayList<String> getCerts(String comp){ 
        try{
            Connection con = DriverManager.getConnection(CONN_STR);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from companies where name = '" + comp + "'");
            ArrayList<String> names=new ArrayList<String>();
 
            while (rs.next()) {
                names.add(rs.getString("mojavez"));             
            }
            con.close();
            return names;
        } catch(java.sql.SQLException ex){
            return new ArrayList <String>();
        }
    }
}
