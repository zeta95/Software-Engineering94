package softwareeng;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class WrongFormatErrorMojavezController implements Initializable {
    
    String passedComp="";
    String selectedMojavez="";
    int sid;
    String dd="";
    String country="";
    String transType="";
    
    ArrayList<Item> items=new ArrayList<Item>();
    
    @FXML
    private void tryAgainAction(ActionEvent event) throws IOException {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Niloomojavez.fxml"));

            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene((Pane) loader.load()));

            NiloomojavezController controller = loader.<NiloomojavezController>getController();
            controller.initData(items,passedComp,selectedMojavez,sid,dd,country,transType);

            stage.show();
            
            ((Node)(event.getSource())).getScene().getWindow().hide();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    
    public void initData(ArrayList<Item> is,String comp,String selectedCert,int ii,String duedate,String c,String tt){
        items=is;
        passedComp=comp;
        selectedMojavez=selectedCert;
        sid=ii;
        dd=duedate;
        country=c;
        transType=tt;
    }
    
}
